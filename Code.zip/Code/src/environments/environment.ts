import {initializeApp} from "firebase/app"
import { getAnalytics } from "firebase/analytics";
export const environment = {
  production: false,
  firebase : {
    apiKey: "AIzaSyBvlDDna0B16l70GOf4yf4eotn1Ftp8i0E",
    authDomain: "demoproject-149f8.firebaseapp.com",
    projectId: "demoproject-149f8",
    storageBucket: "demoproject-149f8.appspot.com",
    messagingSenderId: "502701454091",
    appId: "1:502701454091:web:5a93cbb856a24675dca80e",
    measurementId: "G-1JM1S87PWC"
  }
};


//4/1AX4XfWhCdsVNvZ2ZmqY3d5JalXKzNByC5HUwatxZgkuyFQfkTg1fQL-oaEU
