import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { Firestore, collectionData,collection, FirestoreModule } from '@angular/fire/firestore';
import { doc, setDoc,  getDocs, getFirestore, getDoc } from "firebase/firestore";
import { Observable } from 'rxjs';
import { initializeApp } from "firebase/app"
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  test: any = [];
  item!: Observable<any>;
  constructor(private router: Router, private fb: FormBuilder, private firestore: Firestore,private db1:FirestoreModule
  ) {
    debugger;
    
    const db = getFirestore();
  
    //let dbyy = db.collection("registration");
    const tocoll = collection(firestore, 'Users');
    this.item =collectionData(tocoll);
    const querySnapshot = getDocs(collection(db, "Users"));
    debugger;
    
      }
  registrationForm!: FormGroup;
  cpass: boolean = false;


  ngOnInit(): void {
    
    this.registrationForm = this.fb.group({
      firstName: new FormControl("", [Validators.required]),
      lastName: new FormControl("", [Validators.required]),
      address: new FormControl("", [Validators.required]),
      email: new FormControl("", [Validators.required, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')]),
      password: new FormControl("", [Validators.required, Validators.minLength(6), Validators.maxLength(20), Validators.pattern(/^(?=\D*\d)(?=[^a-z]*[a-z])(?=[^A-Z]*[A-Z]).{6,20}$/)]),
      cPassword: new FormControl("", [Validators.required, Validators.minLength(6), Validators.maxLength(20)]),
    },
      { validator: this.passwordMatchValidator },
    )
  }
  passwordMatchError: string = "Password doesn't match";
  passwordMatch: string = "Password match";
  passwordMatchValidator(frm: FormGroup) {
    return frm.controls['password'].value === frm.controls['cPassword'].value ? null : { 'mismatch': true };
  }

  mailErrorMsg: any = "Please enter valid Email";
  passwordErrorMsg: any = "Password must be at least 6 characters (aA@$).";
  conformPasswordErrorMsg: any = "Password must be at least 6 characters (aA@$).";
  ResetForm() {
    this.registrationForm.reset();
  }
  OnKeyUpEmail() {
    var email = this.registrationForm.get('email')?.value;
    debugger;
    // if (email.length > 0) {
    //   this.mailErrorMsg = "Please enter valid Password";
    // } else {
    //   this.mailErrorMsg = "";
    // }
  }

  // OnKeyUpPassword() {
  //   var pass = this.registrationForm.get('password')?.value;
  //   debugger;
  //   // if (pass.length > 0) {
  //   //  this.passwordErrorMsg= "Password must be at least 6 characters includes with(aA@$).";
  //   //  } else {
  //   //   this.passwordErrorMsg = "";
  //   // }
  // }
  OnKeyUpConformPassword() {
    var cpass = this.registrationForm.get('cPassword')?.value;
    debugger;
    if (cpass.length > 0) {
      this.conformPasswordErrorMsg = "Password must be at least 6 characters.";
    } else {
      this.conformPasswordErrorMsg = "";
    }
  }
  ngDoCheck() {
    console.log("change");
    var test1 = this.registrationForm.get('cPassword')?.invalid;

    if (test1) {

    }
  }
  RedirectAuth() {
    debugger;
    this.router.navigate(["/"]);
  }
  Save() {

  }
}
